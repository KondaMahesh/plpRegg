package com.cg.capstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyRegisterController {
	@RequestMapping(value="all")
public String redirect()
{
	return "login";
	}
}
