package com.cg.capstore.dao;

import com.cg.capstore.dto.Customer;
import com.cg.capstore.dto.Merchant;

public class CapStoreDaoImpl implements ICapStoreDao {

	@Override
	public int addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int addMerchant(Merchant merchant) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer fetchCustomerId(String cemail) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Merchant fetchMerchantId(String memail) {
		// TODO Auto-generated method stub
		return null;
	}

}
